---
title: mdxRs
description: Use the new Rust compiler to compile MDX files in the App Router.
---

> This feature is currently experimental and subject to change, it's not recommended for production. Try it out and share your feedback on GitHub.

For experimental use with `@next/mdx`. Compiles MDX files using the new Rust compiler.

```js filename="next.config.js"
const withMDX = require('@next/mdx')()

/** @type {import('next').NextConfig} */
const nextConfig = {
  pageExtensions: ['ts', 'tsx', 'mdx'],
  experimental: {
    mdxRs: true,
  },
}

module.exports = withMDX(nextConfig)
```
